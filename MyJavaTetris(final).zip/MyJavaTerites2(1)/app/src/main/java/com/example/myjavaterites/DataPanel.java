package com.example.myjavaterites;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.View;

public class DataPanel extends View {




    public DataPanel(Context context, AttributeSet attrs){
        super(context ,attrs);

    }
    public DataPanel(Context context){
        super(context);
    }



    @SuppressLint("ResourceAsColor")
    @Override
    protected void onDraw(Canvas canvas){

        super.onDraw(canvas);

        String score=Map.getThePanel().getScore()+"";
        Paint scorePaint = new Paint();
        scorePaint.setTextSize(80);// 字体大小
        scorePaint.setTypeface(Typeface.DEFAULT_BOLD);// 采用默认的宽度
       scorePaint.setColor(Color.RED);
       scorePaint.setAntiAlias(true);
       canvas.drawText(score,10,100,scorePaint);





    }







}

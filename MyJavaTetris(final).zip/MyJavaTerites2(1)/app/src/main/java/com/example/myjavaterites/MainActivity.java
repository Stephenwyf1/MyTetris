package com.example.myjavaterites;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MarginLayoutParamsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        Toast.makeText(MainActivity.this,"小小和钰夫的项目",Toast.LENGTH_SHORT).show();
        Button button1 =(Button)findViewById(R.id.button_1);
        Button button2=(Button)findViewById(R.id.button_2);
        Button button3=(Button)findViewById(R.id.button_3);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, gameActivity.class);
                startActivity(intent);
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DataActivity.class);
                startActivity(intent);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        ImageView image1=(ImageView)findViewById(R.id.image_title);
        ViewGroup.MarginLayoutParams margin= new ViewGroup.MarginLayoutParams(image1.getLayoutParams());
        margin.setMargins(270,10,0,0);
        RelativeLayout.LayoutParams layoutParams2 =new RelativeLayout.LayoutParams(margin);
        layoutParams2.height = 600;
        layoutParams2.width=600;
        image1.setLayoutParams(layoutParams2);
    }
}

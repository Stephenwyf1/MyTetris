package com.example.myjavaterites;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

public class Nextblock extends View {




    int boxWidth=50;
    int offset= 400;
    int offset2=120;

    public Nextblock(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    public Nextblock(Context context) {
        super(context);
    }


    @SuppressLint("ResourceAsColor")
    @Override
    protected void onDraw(Canvas canvas) {

        Point[] nextBlock = Boxes.getBoxs().getNextBlock();
        Paint panelBoxPaint= new Paint();
        panelBoxPaint.setColor(R.color.block);
        panelBoxPaint.setAntiAlias(true);

        Paint line = new Paint();
        line.setColor(R.color.gameBackgroudLine);

        Paint textPaint = new Paint();
        textPaint.setTextSize(35);// 字体大小
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);// 采用默认的宽度
        textPaint.setColor(R.color.message);
        textPaint.setAntiAlias(true);
        canvas.drawText("The next Block",5,380,textPaint);

        for(int i=0;i<nextBlock.length;i++){
            //矩形绘制
            canvas.drawRect(
                    nextBlock[i].x*boxWidth-offset2,
                    nextBlock[i].y*boxWidth+offset,
                    nextBlock[i].x*boxWidth+boxWidth-offset2,
                    nextBlock[i].y*boxWidth+boxWidth+offset,panelBoxPaint);


            canvas.drawLine(nextBlock[i].x*boxWidth-offset2,nextBlock[i].y*boxWidth+offset,nextBlock[i].x*boxWidth+boxWidth-offset2,nextBlock[i].y*boxWidth+offset,line);
            canvas.drawLine(nextBlock[i].x*boxWidth+boxWidth-offset2,nextBlock[i].y*boxWidth+offset,nextBlock[i].x*boxWidth+boxWidth-offset2,nextBlock[i].y*boxWidth+boxWidth+offset,line);
            canvas.drawLine(nextBlock[i].x*boxWidth+boxWidth-offset2,nextBlock[i].y*boxWidth+boxWidth+offset,nextBlock[i].x*boxWidth-offset2,nextBlock[i].y*boxWidth+boxWidth+offset,line);
            canvas.drawLine(nextBlock[i].x*boxWidth-offset2,nextBlock[i].y*boxWidth+boxWidth+offset,nextBlock[i].x*boxWidth-offset2,nextBlock[i].y*boxWidth+offset,line);


        }



    }
}
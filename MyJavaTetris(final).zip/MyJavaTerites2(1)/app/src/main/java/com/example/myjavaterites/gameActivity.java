package com.example.myjavaterites;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;


public class gameActivity extends AppCompatActivity implements View.OnClickListener {

    View gamePanel;
    View dataPanel;
    View nextBlock;
    public Boxes theBlock = Boxes.getBoxs();
    public Thread downThread;
    public static boolean isPause;
    public static boolean isOver;
    private static final long CLICK_INTERVAL_TIME = 300;
    private static long lastClickTime = 0;
    public int maxScore;

    Handler handlerDataPanel=new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            dataPanel.invalidate();
            nextBlock.invalidate();
        }
    };

    Handler handlerGamePanel = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            gamePanel.invalidate();
        }
    };

    @Override
    public void onClick(View v) {


        switch (v.getId()) {
            //左
            case R.id.buttonLeft:

                theBlock.move(-1, 0);
                break;
            //上
            case R.id.buttonRotate:
                theBlock.rotate();
                break;
            //右
            case R.id.buttonRight:

                theBlock.move(1, 0);
                break;
            //下
            case R.id.buttonStart:

                startGame();
                break;
            //暂停
            case R.id.buttonPause:
                setPause();
                break;
            case R.id.buttonBottom:
                long currentTimeMillis = SystemClock.uptimeMillis();
                if (currentTimeMillis - lastClickTime < CLICK_INTERVAL_TIME) {
                    theBlock.strightToBottom();
                }else{
                    theBlock.move(0,1);
                }
                lastClickTime = currentTimeMillis;
                break;




            //调用重新绘制view

        }
        handlerGamePanel.sendEmptyMessage(0);
    }

    public void intListener() {

        findViewById(R.id.buttonBottom).setOnClickListener(this);
        findViewById(R.id.buttonRotate).setOnClickListener(this);
        findViewById(R.id.buttonPause).setOnClickListener(this);
        findViewById(R.id.buttonStart).setOnClickListener(this);
        findViewById(R.id.buttonRight).setOnClickListener(this);
        findViewById(R.id.buttonLeft).setOnClickListener(this);
    }

    public void setPause() {
        if (isPause)
            isPause = false;
        else
            isPause = true;
    }

    public void startGame() {



        if (downThread == null) {
            downThread = new Thread() {
                @Override
                public void run() {
                    super.run();

                    while (true) {
                        int count=0;
                        try {
                            //休眠500毫秒
                            sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        if ( isPause )
                            continue;
                        else if( isOver )
                            {

                                boolean [][]map= Map.getThePanel().getMap();
                                for (int x = 0; x < map.length; x++) {
                                for (int y = 0; y < map[0].length; y++) {
                                    map[x][y] = false;   //清除地图
                                }
                                   }


                                Map.getThePanel().setScore(0);
                                continue;


                            }
                        //执行一次下落
                       count= theBlock.moveBottom();
                        //5.游戏结束判断
                        isOver = checkOver();
                        //通知自定义View刷新
                         Map.getThePanel().setScore(count);

                         handlerDataPanel.sendEmptyMessage(0);
                         handlerGamePanel.sendEmptyMessage(0);

                    }
                }
            };

            downThread.start();
        }

        Map.getThePanel().setScore(0);
        //游戏结束设为false
        isOver = false;
        //暂停状态设为false
        isPause = false;
//为下一次重新开始游戏做准备
        dataPanel.invalidate();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        getSupportActionBar().hide();

        gamePanel = findViewById(R.id.GamePanel);
        dataPanel = findViewById(R.id.DataPanel);
        nextBlock=  findViewById(R.id.NextBlock);
        intListener();




    }


    public boolean checkOver() {
        for (int i = 0; i < theBlock.getPoints().length; i++) {
            if (Map.getThePanel().getMap()[theBlock.getPoints()[i].x][theBlock.getPoints()[i].y]) {
                return true;
            }
        }
        return false;
    }



}

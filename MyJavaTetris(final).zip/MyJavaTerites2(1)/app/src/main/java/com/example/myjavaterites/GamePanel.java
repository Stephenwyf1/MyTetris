package com.example.myjavaterites;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

    public class GamePanel extends View {


        Boxes boxes= Boxes.getBoxs();
        Paint mapPaint, panelLinePaint, panelBoxPaint; // 用来画出相应对象的画笔
        Point[] block;  // 当前我们的方块，是一个点阵来代表的
        Map Panel = Map.getThePanel(); // 整个游戏视图作为一个二维数组进行呈现
        boolean [][] thePanel = Panel.getMap();



        public GamePanel(Context context, AttributeSet attrs) {
            super(context, attrs);
        }
        public GamePanel(Context context) {
            super(context);
        }



        @SuppressLint("ResourceAsColor")
        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
         //   setBackgroundColor(R.color.gameBackgroud);
            mapPaint = new Paint();
            mapPaint.setColor(R.color.map);
            mapPaint.setAntiAlias(true);

            panelLinePaint =new Paint();
            panelLinePaint.setColor(R.color.gameBackgroudLine);
            panelLinePaint.setStyle(Paint.Style.FILL);
            panelLinePaint.setStrokeWidth(4f);
            panelLinePaint.setAntiAlias(true);

            //初始化方块画笔
            panelBoxPaint=new Paint();
            panelBoxPaint.setColor(R.color.block);
            panelLinePaint.setStyle(Paint.Style.FILL);
            panelBoxPaint.setAntiAlias(true);



            int width=this.getWidth(), height=this.getHeight();
            int boxWidth=width/thePanel.length;
            block = boxes.getPoints();
            boxes.setBoxWidth(boxWidth);

            for(int x=0;x<thePanel.length;x++){

                for(int y=0;y<thePanel[x].length;y++){
                    if(thePanel[x][y]!=false)
                    {

                        canvas.drawRect(x*boxWidth,y*boxWidth,x*boxWidth+boxWidth,y*boxWidth+boxWidth,mapPaint);
                        canvas.drawRect(x * boxWidth, y * boxWidth, x * boxWidth + boxWidth, y * boxWidth + boxWidth, panelBoxPaint);
                    }

                    else {
                        canvas.drawRect(x * boxWidth, y * boxWidth, x * boxWidth + boxWidth, y * boxWidth + boxWidth, panelBoxPaint);
                    }
                }
            }

            for(int x=0;x<thePanel.length;x++){
                canvas.drawLine(x*boxWidth,0,x*boxWidth,height,panelLinePaint);
            }

            for(int x=0;x<thePanel[0].length;x++){
                canvas.drawLine(0,x*boxWidth,width,x*boxWidth,panelLinePaint);
            }

            for(int i=0;i<block.length;i++){
                //矩形绘制
                canvas.drawRect(
                        block[i].x*boxWidth,
                        block[i].y*boxWidth,
                        block[i].x*boxWidth+boxWidth,
                        block[i].y*boxWidth+boxWidth,panelBoxPaint);
            }






        }
    }
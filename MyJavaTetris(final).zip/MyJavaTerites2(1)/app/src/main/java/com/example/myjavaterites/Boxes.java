package com.example.myjavaterites;

import android.graphics.Point;

import java.util.Random;

public class Boxes{

    private static Boxes boxes = new Boxes();
    private Point[] points = new Point[]{new Point(4,1),new Point(5,0),new Point(3,1),new Point(5,1)};
    private Point[] nextBlock= new Point[]{new Point(4,1),new Point(3,0),new Point(3,1),new Point(5,1)};
    private int boxType;
    private int boxWidth;
    private  int fallSpeed = 1;

    public Boxes(){

    }

    public void setBoxWidth(int boxWidth) {
        this.boxWidth = boxWidth;
    }

    //单例模式，用来记录当前操作的方块
    static public Boxes getBoxs(){
        if( boxes == null ){
            boxes = new Boxes();
        }
        return boxes;
    }

    public void newBoxes(){

        exchange();
        Random random=new Random();
        boxType=random.nextInt(7);

        switch (boxType){
            case 0: // 田字型
                nextBlock =new Point[]{new Point(5,1),new Point(5,0),new Point(4,1),new Point(4,0)};
                break;
            //L
            case 1:
                nextBlock =new Point[]{new Point(4,1),new Point(5,0),new Point(3,1),new Point(5,1)};
                break;
            //反L
            case 2:
                nextBlock =new Point[]{new Point(4,1),new Point(3,0),new Point(3,1),new Point(5,1)};
                break;
            //横条
            case 3:
                nextBlock =new Point[]{new Point(3,0),new Point(4,0),new Point(5,0),new Point(6,0)};
                break;
            //凸字形
            case 4:
                nextBlock =new Point[]{new Point(4,1),new Point(5,0),new Point(5,1),new Point(6,1)};
                break;
             //Z字型
            case 5:
                nextBlock =new Point[]{new Point(4,0),new Point(5,0),new Point(5,1),new Point(5,2)};
                break;
                //反Z
            case 6:
                nextBlock =new Point[]{new Point(5,0),new Point(6,0),new Point(4,1),new Point(5,1)};
                break;


        }


    }

    //俄罗斯方块左右以及向下移动
    public boolean move(int x,int y){

        //遍历每个方块，判断是否出界
        for(int i=0; i<points.length; i++){
            //计算预移动的点
            int checkX = points[i].x+x;
            int checkY = points[i].y+y;

            if(checkBoundray(checkX,checkY)){
                //出界则返回false
                return false;
            }
            //遍历每个方块，判断是否和其他俄罗斯方块重叠
            if(checkCollision(checkX,checkY)){
                //重叠则返回false
                return false;
            }
        }

        // 确认可以移动后对方块的位置进行修改
        for(int i=0; i<points.length; i++){
            points[i].x += x ;
            points[i].y += y;
        }
        return true;
    }

    public boolean rotate(){

        //如果当前方块为田字形，旋转失败
        if(boxType==0){
            return  false;
        }
        //遍历方块数组，每一个都绕着中心店点旋转90度
        for(int i=0;i<points.length;i++){
            //顺时针旋转90度
            int checkX=-points[i].y+points[0].y+points[0].x;
            int checkY=points[i].x-points[0].x+points[0].y;

            //将预旋转的点传入边界判断是否出界
            if(checkBoundray(checkX,checkY))
                //如果出界false，旋转失败
                return false;

            // 判断预旋转的点是否与其他方块重叠
            if(checkCollision(checkX,checkY))
                return false;

        }
        //遍历方块数组，每一个都绕着中心店点旋转90度
        for(int i=0;i<points.length;i++){
            //顺时针旋转90度
            int checkX=-points[i].y+points[0].y+points[0].x;
            int checkY=points[i].x-points[0].x+points[0].y;
            points[i].x=checkX;
            points[i].y=checkY;
        }
        return true;
    }


    public int moveBottom() {
        //1.移动成功不做处理
        if (boxes.move(0, fallSpeed))
            return 0;
        //2.移动失败，堆积处理
        for (int i = 0; i < boxes.getPoints().length; i++)
            (Map.getThePanel().getMap())[boxes.getPoints()[i].x][boxes.getPoints()[i].y] = true;
        //3.消行处理
       int count= Map.getThePanel().cleanLine();
        //4.生成新的方块
        boxes.newBoxes();
        return count;
    }

    //判断是否碰到边界
    public boolean checkBoundray(int x,int y){
        // 获取map
        boolean[][] map = Map.getThePanel().getMap();
        if(x<0||x>=map.length){
            return true;
        }
        if(y<0||y>=map[0].length){
            return true;
        }

        return false;
    }

    //判断是否与其他方块接触，如果接触了则返回true，没有接触则返回false
    public boolean checkCollision(int x,int y){

        //获取map
        boolean[][] map=Map.getThePanel().getMap();

        //获取对应位置map的状态
        boolean mapstate = map[x][y];
        if( mapstate == true ){
            //如果要移动的位置已经存在其他方块，返回true
            return true;
        }
        return false;
    }


    public void strightToBottom(){
        for(int i=10;i>1;i--)
            move(0,i);
    }
    //用来获取方块的点集合
    public Point[] getPoints() {
        return points;
    }

    public void exchange(){

        for(int i = 0;i<points.length;i++)
          {
              points[i].x=nextBlock[i].x;
              points[i].y=nextBlock[i].y;

          }


    }

    public Point[] getNextBlock()
    {

        return nextBlock;

    }

}


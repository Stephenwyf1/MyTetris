package com.example.myjavaterites;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Map {

    private boolean map[][];
    private static Map thePanel = new Map(10,20);
    private int score = 0;


    Map(int x, int y){

        map = new boolean[x][y];

    }




    public static Map getThePanel() {
        return thePanel;
    }

    public boolean[][] getMap() {
        return map;
    }

    public int cleanLine(){
        int count =0;
        for(int y=map[0].length-1;y>0;y--){
            //执行判断
            if(checkLine(y)) {
                //执行消行
                deleteLine(y);
                //消掉的那一行开始重新遍历
                y++;
                count++;
//                score = score + 10 ;

            }
        }
        return count;
    }

    public boolean checkLine(int y){
        for(int x=0;x<map.length;x++){
            //如果有一个不为true，则这一行不能消除
            if(!map[x][y])
                return  false;
        }
        return true;
    }
    /*执行消行*/
    public void deleteLine(int dy){
        for(int y=dy;y>0; y--){
            for(int x=0;x<map.length;x++){
                map[x][y]=map[x][y-1];
            }
        }
    }
    public void setScore(int count){
            this.score+=count*10;
         }

    public int getScore() {
        return score;
    }
}

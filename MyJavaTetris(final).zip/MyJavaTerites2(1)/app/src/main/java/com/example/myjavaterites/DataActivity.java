package com.example.myjavaterites;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class DataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);
        TextView t1 = (TextView) findViewById(R.id.textView);
        TextView t2 = (TextView) findViewById(R.id.textView2);
        int gameScore = 0;
        int maxScore = 0;
        String scoreView = "0";
        Context ctx = DataActivity.this;

        // 加粗
        t1.setTypeface(Typeface.DEFAULT_BOLD);
        t1.setTextColor(Color.BLACK);

        //设置分数的下划线和颜色
        t2.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        t2.getPaint().setAntiAlias(true);
        t2.setTextColor(Color.BLUE);

        // 读取历史最高分
        try {
            FileInputStream fileInputStream = ctx.openFileInput("score.txt");
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int len=10;
            byte[] data = new byte[1024];
            while((len = fileInputStream.read(data))!=-1){
                byteArrayOutputStream.write(data,0,len);
            }
            if(fileInputStream!=null){
                    fileInputStream.close();;}

            scoreView =new String(byteArrayOutputStream.toByteArray());
            maxScore = Integer.parseInt(scoreView);

        } catch (Exception e) {
            e.printStackTrace();
        }

        // 将最高分设置给文本框
        t2.setText(scoreView);
        // 读取游戏分数
        gameScore = Map.getThePanel().getScore();

        //如果游戏得分高于历史最高分，将游戏得分写入文件
        if(gameScore>maxScore) {
            try {
                FileOutputStream fileOutputStream = ctx.openFileOutput("score.txt", Context.MODE_PRIVATE);
                fileOutputStream.write((gameScore+"").getBytes());

                // 将最高分设置为本次游戏得分
                t2.setText(gameScore+"");
                if(fileOutputStream!=null){
                    fileOutputStream.close();
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}

